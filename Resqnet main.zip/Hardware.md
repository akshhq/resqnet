ESP-WROOM-32 WIFI Bluetooth Networking Smart Component Development Board
SKU: 835800
₹ 381.00

GY-NEO6MV2 GPS Module With Flight Control Only Red Board
SKU: R228905
₹ 331.00

SIM800L V2 5V Wireless GSM GPRS MODULE Quad-Band with Antenna
SKU: 43118
₹ 494.00

MPU-6050 3-Axis Accelerometer and Gyro Sensor
SKU: 2846
₹ 169.00

Tactile Push Button Switch 6x6x5 (Pack of 10)
SKU: 618182
₹ 15.00

5V Active Electromagnetic Buzzer
SKU: 616166
₹ 16.00

TP4056 1A Li-ion lithium Battery Charging Module With Current Protection - Mini USB
SKU: 53264
₹ 36.00

LED Traffic Lights Signal Module / Digital Signal Output Traffic Light Module
SKU: 44079
₹ 34.00

100Pcs. 1/4W Metal Film Resistors Assortment for DIY Electronic Projects and Experiments
SKU: R228986
₹ 117.00

NOVA 103450 2000mAh 3.7V Micro LiPo Battery pack with PCB and 75mm Cable of 24AWG
SKU: R218005
₹ 314.00

GL-12 840 Points Solderless Breadboard
SKU: 24441
₹ 59.00

2N2222 NPN Transistor
SKU: 598373
₹ 2.00

5x
10 Wire Male to Female Jumper Wires - 20cm
SKU: R160077
₹ 14.00

Micro USB-A to Micro-B Cable 100cm Data & Power Cable
SKU: 1008666
₹ 44.00

25PK1000MEFC10X16-RUBYCON-ALUMINUM ELECTROLYTIC CAPACITOR, 1000UF, 25V, 20%, RADIAL
SKU: R102003
₹ 26.00