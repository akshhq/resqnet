# ResQNet — Master TODO List

> Updated to reflect the current state of the project: all Section 1–5 items are complete and verified, the dashboard has been rebuilt with a sidebar + integrated dual-simulator layout, CSS has been externalized, and Docker has been removed from the project entirely.

---

## Table of Contents

1. [✅ Bugs & Code Issues — COMPLETE](#1-bugs--code-issues--complete)
2. [✅ Backend Fixes — COMPLETE](#2-backend-fixes--complete)
3. [✅ Simulator Fixes — COMPLETE](#3-simulator-fixes--complete)
4. [✅ Dashboard Fixes — COMPLETE (Superseded by Rebuild)](#4-dashboard-fixes--complete-superseded-by-rebuild)
5. [✅ Security — COMPLETE](#5-security--complete)
6. [🆕 Dashboard Rebuild — Sidebar + Dual Simulator](#6-dashboard-rebuild--sidebar--dual-simulator)
7. [Architecture](#7-architecture)
8. [Testing & CI](#8-testing--ci)
9. [DevOps & Repo Hygiene](#9-devops--repo-hygiene)
10. [Dashboard 1 — User Account Dashboard](#10-dashboard-1--user-account-dashboard)
11. [Dashboard 2 — Emergency Responder Dashboard](#11-dashboard-2--emergency-responder-dashboard)
12. [Dashboard 3 — Operations Command Center](#12-dashboard-3--operations-command-center)
13. [Dashboard 4 — Admin / Org Dashboard](#13-dashboard-4--admin--org-dashboard)
14. [Features & Product](#14-features--product)
15. [Hardware (Future)](#15-hardware-future)

---

## 1. Bugs & Code Issues — ✅ COMPLETE

All 13 items fixed and verified directly against live source on `main`.

| # | Issue | Status |
|---|---|---|
| 1.1 | `reset` flag missing from broadcast payload | ✅ Fixed |
| 1.2 | `device_history` unbounded memory growth | ✅ Fixed — `deque(maxlen=1000)` |
| 1.3 | Escalation skips levels on infrequent updates | ✅ Fixed — advances all pending levels in one pass |
| 1.4 | Battery precision loss, no low-battery alert | ✅ Fixed |
| 1.5 | `replay()` faked a WebSocket event object | ✅ Fixed — calls `handlePayload()` directly |
| 1.6 | No WS reconnection, static error text | ✅ Fixed — exponential backoff 1s→30s |
| 1.7 | Map re-centres every second | ✅ Fixed — only pans when out of bounds |
| 1.8 | Timeline/log DOM nodes grow forever | ✅ Fixed — capped at 100–200 entries |
| 1.9 | No Pydantic validation on lat/lng/speed/battery | ✅ Fixed — `Field(ge=…, le=…)` constraints |
| 1.10 | `BACKEND_URL`/`DEVICE_ID` hardcoded | ✅ Fixed — CLI args `--url --id` |
| 1.11 | Movement only went northeast | ✅ Fixed — heading-based model, any direction |
| 1.12 | Missing viewport meta tag | ✅ Fixed |
| 1.13 | WebSocket URL hardcoded to `127.0.0.1` | ✅ Fixed, then **re-fixed** — see note below |

> **Follow-up note on 1.13:** the WS URL was changed to use `window.location.hostname` for portability, but this caused a real bug on Windows — `localhost` can resolve to the IPv6 loopback `::1`, while uvicorn was bound only to `127.0.0.1` (IPv4). The WebSocket silently failed to connect, looking exactly like "backend not running" even when it was. **Fixed by binding uvicorn to `--host 0.0.0.0`** (accepts both IPv4 and IPv6) and hardcoding the dashboard's WS URL to `127.0.0.1` explicitly, since backend and dashboard always run on the same machine in this prototype.

---

## 2. Backend Fixes — ✅ COMPLETE

| # | Item | Status |
|---|---|---|
| 2.1 | `requirements.txt` with all runtime deps | ✅ Done — includes `websockets`, `python-multipart`, `python-dotenv`, `slowapi` |
| 2.2 | CORS origins from `.env` | ✅ Done |
| 2.5 | `/test/broadcast` debug endpoint | ✅ Removed entirely |
| 2.3 | Replace `print()` with `logging` module | ⏳ Still pending — see [Section 7](#7-architecture) |
| 2.4 | API versioning `/api/v1/` prefix | ⏳ Still pending |
| 2.6 | Graceful WS shutdown on server stop | ⏳ Still pending |

---

## 3. Simulator Fixes — ✅ COMPLETE

| # | Item | Status |
|---|---|---|
| 3.1 | Graceful Ctrl+C shutdown | ✅ Done |
| 3.2 | `--demo` scripted scenario mode | ✅ Done |
| 3.3 | Low-battery alert at 20% | ✅ Done |

**New since original TODO:** the Python simulator now auto-loads `backend/.env` via `python-dotenv` so the API key is found automatically without manual environment setup in the terminal — this was a real bug users hit (403s on every request because the simulator's terminal didn't have `API_KEY` set even though `.env` did).

---

## 4. Dashboard Fixes — ✅ COMPLETE (Superseded by Rebuild)

The original 6 items (connection dot, movement trail, battery bar, ISO timestamp, audio alert, replay UI) are all implemented. However, **the entire dashboard was subsequently rebuilt** with a sidebar + integrated simulator layout (see [Section 6](#6-dashboard-rebuild--sidebar--dual-simulator)), which carries all of these features forward into the new layout. This section is kept for historical reference only — refer to Section 6 for current dashboard state.

---

## 5. Security — ✅ COMPLETE

| # | Item | Status |
|---|---|---|
| 5.1 | API key auth on all HTTP endpoints | ✅ Done — `auth.py`, optional via `.env` |
| 5.2 | WebSocket token validation | ✅ Done — `?token=<key>` query param |
| 5.3 | Rate limiting | ✅ Done — `slowapi`, 60/min update, 30/min history |
| 5.4 | Registered device list | ✅ Done — `/device/register` required before `/device/update` |

**Key design decision:** auth is **optional and off by default**. With no `API_KEY` in `.env`, all requests pass through (dev mode) — the system works with zero configuration. The moment `API_KEY` is set, every endpoint enforces it automatically. This was chosen after early versions made auth mandatory, which caused confusing 422/403 errors for anyone just trying to run the project locally.

**Bugs found and fixed during implementation:**
- `_rate_limit_exceeded_handler` imported from `slowapi` privately — signature changed across versions, caused a type error. Replaced with a custom handler in `auth.py`.
- WebSocket endpoint called `verify_ws_token()` *before* `websocket.accept()` — you cannot close an unaccepted WebSocket, so invalid tokens caused the connection to hang silently instead of closing. Fixed: accept first, then validate, then close if invalid.
- Dashboard's `applyApiKey()` nulled out `ws.onclose` before closing the socket to apply a new key — this broke the reconnect chain entirely after the first key entry. Fixed: leave `onclose` intact so `connect()` is called naturally on close.

---

## 6. Dashboard Rebuild — Sidebar + Dual Simulator

Major redesign completed. The dashboard is no longer a single floating-panels-over-map layout — it's now a structured sidebar + map application.

### 6.1 — Layout

- **Left sidebar** (320px fixed width), split exactly 50/50 vertically:
  - **Top half — Device list**: every active device as a card (name, status dot, speed, context, risk pill, battery %, per-device controls)
  - **Bottom half — Movement log**: shows the log of whichever device is currently selected, switches instantly on click, capped at 200 entries
- **Map fills the remaining width** — auto-pans only when the *selected* device leaves visible bounds; never locked to one device, fully free to pan/zoom at any time

### 6.2 — In-browser simulator (new)

The dashboard now has its own complete simulator engine written in JS — no Python process required to test the system:
- **+ Add Device** button opens a modal: name, preset city dropdown or custom lat/lng, starting mode
- Each device runs its own independent `setInterval` tick loop (1Hz)
- Uses the **same heading-based movement model** as the Python simulator: gaussian speed noise, smooth lerp, GPS jitter, brief pauses
- Per-device controls directly on each card: 🚨 Panic, ✅ Reset, mode dropdown, ↩ Sharp Turn, ✕ Remove
- POSTs to `/device/register` and `/device/update` exactly like the Python simulator — the backend cannot tell the difference

### 6.3 — Dual simulator support (new)

The dashboard and the Python `simulator.py` can now run **simultaneously**, with devices from both appearing together on the same map and in the same sidebar.

**How it works:** every device is tagged `isLocal: true` (created via the browser's Add Device button) or `isLocal: false` (driven entirely by backend broadcasts — i.e., from the Python simulator, `send_updates.py`, or another browser tab). A new `handleBroadcast()` function auto-creates a device card the **first time** it sees a broadcast for an unrecognized `device_id`, then keeps syncing its position/state from every subsequent broadcast. Local devices skip this re-render (their own tick loop already handles it) and only sync authoritative `risk`/`escalation`/`reset` fields from the backend.

**Bug found and fixed:** originally, `ws.onmessage` only updated devices that already existed in the browser's local device registry — broadcasts from the Python simulator were silently discarded because no card existed for them yet. This made it look like "the device isn't showing up" even though the backend was broadcasting correctly. Fixed by the auto-create logic above.

### 6.4 — External CSS (new)

All styling was extracted from the inline `<style>` block in `index.html` into a standalone `style.css` file, linked via `<link rel="stylesheet" href="style.css">`. No functional changes — purely a code organization improvement for maintainability.

### 6.5 — `start.bat` / `start.sh` updated for dual simulator

Both scripts now treat the Python simulator as **optional** rather than auto-launching it, since the dashboard has its own:

```bash
start.bat               # backend + dashboard only — use "+ Add Device" in browser
start.bat --with-sim    # ALSO launches the Python simulator alongside the browser one
start.bat --demo        # ALSO launches the Python simulator in demo mode
```

---

## 7. Architecture

Items not yet addressed, carried forward from the original Section 6/Section 2 backend work.

### 7.1 — Logging
Replace remaining `print()` statements with Python's `logging` module — levels, timestamps, optional file output. Currently the backend prints emoji-prefixed status lines directly to stdout, which works for local dev but won't scale to a real deployment with log aggregation.

### 7.2 — API versioning
Prefix all routes with `/api/v1/` so future breaking changes don't immediately break the dashboard, simulators, or any future client. Not yet done — would require updating `BACKEND` constant in `script.js` and `BACKEND_URL` in `simulator.py` simultaneously.

### 7.3 — Persistent storage
All state (`device_state`, `device_history`, `escalation_state`, `registered_devices`) is still in-memory only. A backend restart wipes everything — including the registered device list, meaning the Python simulator would need to re-register after every backend restart (it already auto-registers on startup, so this is low-impact right now, but matters once real devices are involved). Plan: SQLite first, PostgreSQL for any real multi-instance deployment.

### 7.4 — Graceful WebSocket shutdown
When the backend process stops (Ctrl+C or crash), connected WebSocket clients get a raw disconnect with no explanation. Add a shutdown handler in the `lifespan` teardown that sends a close frame with a reason to all active connections before the process exits.

### 7.5 — Concurrent broadcast
`ConnectionManager.broadcast()` currently iterates connections and awaits each `send_json()` in sequence. A slow client could delay broadcasts to everyone else. Switch to `asyncio.gather()` for concurrent sends.

### 7.6 — Multi-instance support
Not relevant yet at current scale (a handful of simulated devices), but if this were ever deployed with multiple backend instances behind a load balancer, in-memory state would break — WebSocket clients connected to instance A wouldn't see broadcasts from updates that hit instance B. Would need Redis Pub/Sub or similar.

---

## 8. Testing & CI

Nothing has been built here yet. Recommended order:

### 8.1 — Unit tests for `context.py`
Highest value, lowest effort. Test `classify_context()`, `detect_speed_anomaly()`, `calculate_risk()`, `should_alert()`, and especially `check_escalation()` — this function has already had one real bug (the multi-level-skip issue from Section 1.3) and deserves regression protection.

### 8.2 — Integration tests for the full update cycle
Use `httpx.AsyncClient` + FastAPI's `TestClient` (already used informally during manual testing in this conversation) to assert: register → update → broadcast → history all behave correctly together. Also test the auth dependency injection — both with and without `API_KEY` set.

### 8.3 — GitHub Actions CI
Run `pytest` on every push/PR. Currently zero automated checks exist — every fix in this project so far has been manually verified via ad-hoc `TestClient` scripts in conversation, which doesn't scale and isn't repeatable by anyone else working on the repo.

### 8.4 — Linting
Add `ruff` for fast linting and `black` for formatting, with a pre-commit hook so style issues are caught before commit rather than accumulating.

---

## 9. DevOps & Repo Hygiene

| # | Item | Status |
|---|---|---|
| `.gitignore` | ✅ Done |
| `LICENSE` (MIT) | ✅ Done |
| `start.bat` / `start.sh` | ✅ Done — now handle dual-simulator flags, bind `0.0.0.0` |
| `backend/.env.example` | ✅ Done |
| ~~Docker support~~ | ❌ **Removed entirely** — see note below |
| README screenshots | ⏳ Not yet — would help, especially showing the new sidebar layout |
| `workshop1.xlsx` / `workshop2.xlsx` cleanup | ⏳ Not yet confirmed removed |

> **Docker removed:** `Dockerfile`, `Dockerfile.simulator`, and `docker-compose.yml` were deleted from the project. Docker added complexity (container networking, volume mounts, image rebuilds) without clear benefit for a local-only prototype that already has working one-command startup scripts (`start.bat` / `start.sh`). If deployment to a real server becomes a near-term goal, Docker can be reintroduced at that point — but it is **not needed** for local development or testing.

---

## 10. Dashboard 1 — User Account Dashboard

*(Unchanged from original plan — not yet started.)*

Personal dashboard for the device owner:
- Phone OTP authentication
- Manage registered devices (name, battery, last seen, connection status) — note: the current in-browser simulator's device cards are a rough visual precedent for what this could look like
- Edit emergency contacts with priority order and per-contact notification method
- Notification preferences and quiet hours
- Full incident history with timeline replay
- Progressive Web App (PWA) for home screen install and offline contacts

---

## 11. Dashboard 2 — Emergency Responder Dashboard

*(Unchanged from original plan — not yet started.)*

For trusted contacts receiving the alert:
- One-time session token sent via SMS on emergency trigger (no password needed in a crisis)
- Live map with movement trail and speed context
- "I'm on my way" acknowledgement button
- Live audio stream from device microphone (with user consent)
- Multi-responder view (see who else is watching)
- Session auto-expires after reset + 30 minutes

---

## 12. Dashboard 3 — Operations Command Center

*(Unchanged from original plan — not yet started, but partially de-risked.)*

For organisations (universities, NGOs) monitoring many devices:
- Real-time map of all registered devices, colour-coded by status — **the current dashboard's multi-device sidebar + map is a working prototype of this core idea**, just without org-level scoping, responder assignment, or geofencing yet
- Active incidents panel with responder assignment
- Geofence zones with auto-routing of incidents to zone responders
- Regional statistics and average response time
- Incident log with CSV export

---

## 13. Dashboard 4 — Admin / Org Dashboard

*(Unchanged from original plan — not yet started.)*

For organisation administrators:
- User and device management
- Responder roster and shift management
- Alert delivery audit log (did the SMS actually deliver?)
- Customisable escalation thresholds per organisation
- Monthly incident reports

---

## 14. Features & Product

### 14.1 — Notifications (not yet started)
- Email via SMTP/SendGrid
- SMS via Twilio
- WhatsApp via Twilio WhatsApp API
- Push via Firebase Cloud Messaging

### 14.2 — RBAC design (not yet started)
Needs to happen before any of Dashboards 1–4 are built — see role matrix in earlier planning.

### 14.3 — Device registration flow (partially done)
Backend enforcement exists (`/device/register`, rejection of unregistered IDs). What's missing: a proper UI flow for a *real* device to register itself (currently only the simulators call this endpoint programmatically).

### 14.4 — Safe check-in feature (not yet started)

---

## 15. Hardware (Future)

*(Unchanged — not started.)*

- ESP32 + NEO-M8N GPS module
- Physical panic button on GPIO with debounce
- MQTT communication to backend
- LiPo battery + TP4056 charger, INMP441 I2S microphone
- OTA firmware updates
- Target form factor: < 40g, wrist-wear or clip-on

---

## Priority Matrix — Updated

| # | Task | Priority | Status |
|---|------|----------|--------|
| 1–5 | All bugs, backend, simulator, dashboard fixes, security | — | ✅ **Done** |
| 6 | Dashboard rebuild (sidebar + dual simulator) | — | ✅ **Done** |
| 9 | Docker removal | — | ✅ **Done** |
| 7.1 | Replace `print()` with `logging` | 🟡 Medium | Next |
| 7.3 | Persistent storage (SQLite) | 🔴 High | Next |
| 8.1 | Unit tests for `context.py` | 🟡 Medium | Next |
| 8.3 | GitHub Actions CI | 🟡 Medium | Next |
| 14.1 | Notifications (email first) | 🔴 High | After persistence |
| 14.2 | RBAC design | 🔴 High | Before any new dashboard |
| 10 | Dashboard 1 (User Account) | 🔴 High | After RBAC |
| 11 | Dashboard 2 (Responder) | 🔴 High | After Dashboard 1 |
| 12 | Dashboard 3 (Command Center) | 🟡 Medium | After Dashboard 2 |
| 13 | Dashboard 4 (Org Admin) | 🟠 Low | After Dashboard 3 |
| 15 | Hardware (ESP32) | 🟠 Low | After software stable |

---

*Last updated to reflect: Section 1–5 verification, dashboard sidebar rebuild, dual-simulator integration, external CSS, Docker removal, and three real bugs found and fixed during security implementation (rate limit handler, WS accept-before-close, applyApiKey reconnect chain).*