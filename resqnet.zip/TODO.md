# ResQNet — Master TODO List

> Updated after wiring the User Dashboard, Responder Dashboard, Postgres schema, and both Google Apps Scripts together end-to-end. Sections 1–9 (core backend, Trial Dashboard, security) were already complete and are summarized only. This revision focuses on what changed in the User/Responder/Postgres integration pass and what's still open.

---

## Table of Contents

1. [✅ Core Backend, Trial Dashboard, Security — COMPLETE (summary)](#1-core-backend-trial-dashboard-security--complete-summary)
2. [✅ User + Responder Dashboard Integration — COMPLETE](#2-user--responder-dashboard-integration--complete)
3. [🐛 Bugs Found & Fixed This Pass](#3-bugs-found--fixed-this-pass)
4. [Architecture — Still Open](#4-architecture--still-open)
5. [Testing & CI](#5-testing--ci)
6. [DevOps & Repo Hygiene](#6-devops--repo-hygiene)
7. [Dashboard 3 — Operations Command Center](#7-dashboard-3--operations-command-center)
8. [Dashboard 4 — Admin / Org Dashboard](#8-dashboard-4--admin--org-dashboard)
9. [Features & Product](#9-features--product)
10. [Hardware (Future)](#10-hardware-future)
11. [Priority Matrix](#priority-matrix)

---

## 1. Core Backend, Trial Dashboard, Security — ✅ COMPLETE (summary)

Everything from the original TODO's Sections 1–5 is done and unchanged by this pass: reset-flag broadcast, bounded history (`deque(maxlen=1000)`), multi-level escalation, Pydantic validation, heading-based movement model, optional API-key auth + WS token, rate limiting via `slowapi`, mandatory device registration. The Trial Dashboard (sidebar + map, dual simulator support, external CSS, dark mode) is untouched by this pass — it doesn't use Postgres or either Apps Script at all.

---

## 2. User + Responder Dashboard Integration — ✅ COMPLETE

This was the actual point of this pass: the User Dashboard and Responder Dashboard existed as frontend code and a partially-built backend, but **nothing was actually wired together**. Fixed:

| # | Item | Status |
|---|---|---|
| 2.1 | `user_router` and `email_queue_router` were never mounted in `main.py` — every `/user/*` call except the two shadowed duplicates was 404ing in production | ✅ Fixed — mounted via `app.include_router()` |
| 2.2 | Duplicate in-memory `/user/register` / `/user/login` directly on `app` in `main.py`, shadowing the real Postgres-backed router | ✅ Removed |
| 2.3 | `user_db.init_user_tables()` was never called — none of the User Dashboard's Postgres tables existed at runtime | ✅ Fixed — called in `lifespan()` after `db.init_db()` |
| 2.4 | Schema redesigned to the spec'd 4-table shape: `users`, `devices` (no owner column), `user_devices` (relation table), `emergency_contacts` (email-first, phone optional) | ✅ Done |
| 2.5 | `user_id` scheme changed from `name_DOB` to `firstname_lastname_phonenumber` | ✅ Done |
| 2.6 | Nothing ever called the Emergency Session Token Apps Script — an emergency starting never notified anyone | ✅ Fixed — `main.py`'s `device_update()` now looks up the owning user via `user_devices` and calls `action=trigger` |
| 2.7 | Emergency contacts were never included in any notification — only the fixed `RESPONDER_EMAILS` list got alerted | ✅ Fixed — backend forwards `contactEmails`; Apps Script emails them a personal-alert version of the same link |
| 2.8 | Responder Dashboard's two frontend files (`script.js`, `responder-dashboard-frontend.js`) existed but only one was loaded, and the loaded one had a literal `[STUB]` for magic-link handling | ✅ Merged — `?uid=&token=` now validates and feeds `deviceId` into the existing live-map code |
| 2.9 | Incident resolution only ever happened in the Apps Script's Google Sheet — the Postgres `incidents` row never closed, so User Dashboard incident history would drift out of sync forever | ✅ Fixed — device reset now auto-calls both the Apps Script's `action=resolve` and the new `POST /user/incidents/resolve-by-token` |
| 2.10 | `httpx` (needed for the backend → Apps Script server-to-server call) wasn't in `requirements.txt` | ✅ Added |
| 2.11 | Placeholder "Voice Monitoring" card for future device-mic linking | ✅ Added to User Dashboard (disabled, no backend logic yet — see [Section 9](#9-features--product)) |
| 2.12 | Demo/simulator account | ✅ `simulator/seed_simulator_user.py` creates a real user + device through the actual API, then hands the `device_id` straight to `simulator.py` |
| 2.13 | Both Apps Scripts version-controlled in the repo (`apps_script/`) rather than living only in the Apps Script editor | ✅ Done |

---

## 3. Bugs Found & Fixed This Pass

Worth calling out individually — these weren't in the original TODO because the code they're in didn't exist yet at the time it was written:

- **`backend/requirements.txt` was UTF-16 encoded.** `pip install -r` on a UTF-16 file fails on most systems (pip opens text files with the platform default encoding, not a BOM-sniffing one). Converted to plain UTF-8/ASCII.
- **`dob_not_future` Pydantic validator was typed `date` but the field is `str`.** `UserRegister.dob` is declared as `str` (`"YYYY-MM-DD"`) but its `@field_validator` took/returned a `date` object — this would have raised a `TypeError` the first time anyone actually registered. Fixed to parse the string internally.
- **`EmergencyContactIn`/`EmergencyContactUpdate` required `phone`, made `email` optional** — backwards from the "email-first" contacts spec. Swapped: `email` required, `phone` optional.
- **`add_contact()` in `user_routes.py` called `add_emergency_contact()` with arguments in the wrong order** relative to the (email-first) function signature — `phone` and `email` were transposed, and the three `notify_*` flags were passed in the wrong order entirely. Fixed.
- **Stale error message** on `/user/register`'s 409 conflict still referenced the old "name+DOB combination" uniqueness rule after the schema moved to phone/email uniqueness. Fixed.

---

## 4. Architecture — Still Open

Carried forward from before this pass, still true:

### 4.1 — Logging
Replace remaining `print()` calls (including the new ones in `_trigger_responder_alert()`) with the `logging` module.

### 4.2 — API versioning
Prefix all routes with `/api/v1/`. Would need updates in `Trial_Dashboard/script.js`, `frontend/user_dashboard/app.js`, `frontend/responder_dashboard/script.js`, and `simulator/simulator.py` simultaneously.

### 4.3 — Persistent live state
`device_state`, `device_history`, `escalation_state`, and the in-memory `registered_devices` set are still wiped on every backend restart. Postgres now persists *accounts, devices, contacts, and incidents* — but the live tick-by-tick state (used for the WS broadcast and `/device/{id}` reads) is still in-memory only. Low-impact for the simulator (auto-registers on startup) but matters for real devices.

### 4.4 — Graceful WebSocket shutdown
No close-frame is sent to connected clients when the backend stops.

### 4.5 — Concurrent broadcast
`ConnectionManager.broadcast()` still awaits each `send_json()` in sequence — a slow client delays broadcasts to everyone else. Switch to `asyncio.gather()`.

### 4.6 — Multi-instance support
Not relevant at current scale, but in-memory `device_state`/WS connections would break across multiple backend instances behind a load balancer. Would need Redis Pub/Sub.

### 4.7 — Two systems of record for incidents
The Apps Script Sheet and the Postgres `incidents` table are now both closed on resolve (see 2.9), but they're still two separate systems that happen to be kept in sync by calling both explicitly. If either call silently fails (network blip to the Apps Script, or the backend being down when the responder page tries to reach it), they can drift. Worth a periodic reconciliation job eventually, not urgent yet.

---

## 5. Testing & CI

Still nothing built here. Recommended order, updated for the new surface area:

### 5.1 — Unit tests for `context.py`
Same as before — highest value, lowest effort. `check_escalation()` has already had one real regression.

### 5.2 — Unit tests for `user_db.generate_user_id()` / `generate_device_id()`
New and worth covering given the ID scheme just changed — edge cases: single-word names, names with non-letter characters, phone numbers with country codes/symbols.

### 5.3 — Integration test for the emergency notification path
Mock the Apps Script HTTP call and assert: emergency starts → `get_owner_user_id()` called → `_trigger_responder_alert()` called with the right `contactEmails` → `incidents` row created with the returned token → device reset → both resolve calls fire.

### 5.4 — GitHub Actions CI
Run `pytest` on every push/PR — still zero automated checks exist anywhere in the repo.

### 5.5 — Linting
`ruff` + `black` + pre-commit hook.

---

## 6. DevOps & Repo Hygiene

| # | Item | Status |
|---|---|---|
| `.gitignore`, `LICENSE`, `start.bat`/`start.sh` | ✅ Done (unchanged) |
| `backend/env.example` | ✅ Updated — documents `SESSION_TOKEN_WEBAPP_URL` |
| Apps Script source version-controlled | ✅ Done — `apps_script/` |
| `workshop1.xlsx` / `workshop2.xlsx` cleanup | ⏳ Still not confirmed removed |
| README screenshots | ⏳ Not yet — especially the Responder Dashboard's magic-link flow |
| Neon schema migration for existing dev/test data | ⚠️ **Action needed** — if tables were already created under the old schema (owner column on `devices`, `name_DOB` user_id, phone-required contacts) during earlier testing, drop them before restarting the backend; `init_user_tables()` only does `CREATE TABLE IF NOT EXISTS`, it will not migrate old rows |

---

## 7. Dashboard 3 — Operations Command Center

*(Unchanged from original plan — not started.)* Real-time map of all registered devices across an organisation, active-incidents panel with responder assignment, geofence zones, regional stats, CSV export. The current `incidents` table and `user_devices` relation give this a real data foundation to build against now, where before it would have needed its own schema from scratch.

---

## 8. Dashboard 4 — Admin / Org Dashboard

*(Unchanged from original plan — not started.)* User/device management, responder roster, alert delivery audit log, per-org escalation thresholds, monthly reports. Needs RBAC design first (see 9.2).

---

## 9. Features & Product

### 9.1 — Voice monitoring (placeholder added, not implemented)
The User Dashboard now has a disabled "Voice Monitoring" card reserving the UI slot. Actually implementing it needs: backend WebRTC signaling, an explicit per-device consent flow (distinct from the responder-side consent-gated demo button that already exists in `frontend/responder_dashboard/script.js`), and a real audio pipeline from device mic → responder dashboard.

### 9.2 — RBAC design (not started)
Needed before Dashboards 3–4. The `users`/`devices`/`user_devices` split from this pass gives a cleaner foundation for this than the old single-table design would have.

### 9.3 — SMS / WhatsApp notifications (not started)
`emergency_contacts` already has `notify_sms` and `notify_whatsapp` boolean columns, unused so far — only `notify_email` is acted on. Twilio or Fast2SMS integration would read those flags the same way `_trigger_responder_alert()` reads `notify_email` today.

### 9.4 — Email queue / Phase 4 (schema ready, nothing enqueues yet)
`email_queue` table and `/email-queue/pending`, `mark-sent`, `mark-failed` all exist and work, per `EMAIL_QUEUE_INTEGRATION.md` — but nothing in the codebase calls `enqueue_email()` yet. The emergency-alert path currently goes straight through the Apps Script's own `GmailApp.sendEmail()`, bypassing this queue entirely. Worth deciding whether emergency alerts should eventually move onto this queue too, or whether the direct Apps Script path stays as the low-latency emergency channel and the queue stays reserved for non-urgent email (e.g. incident summaries, weekly digests).

### 9.5 — Safe check-in feature (not started)

---

## 10. Hardware (Future)

*(Unchanged — not started.)* ESP32 + NEO-M8N GPS, physical panic button, MQTT, LiPo + TP4056, INMP441 mic, OTA updates, target < 40g wrist-wear/clip-on form factor.

---

## Priority Matrix

| # | Task | Priority | Status |
|---|------|----------|--------|
| 1–2 | Core backend/security + User/Responder Dashboard integration | — | ✅ **Done** |
| 6 | Neon schema check for stale old-shaped tables | 🔴 High | **Do before next deploy** |
| 4.1 | Replace `print()` with `logging` | 🟡 Medium | Next |
| 4.3 | Persistent live state | 🔴 High | Next |
| 5.1–5.3 | Unit + integration tests | 🟡 Medium | Next |
| 5.4 | GitHub Actions CI | 🟡 Medium | Next |
| 9.3 | SMS/WhatsApp notifications | 🔴 High | After tests |
| 9.2 | RBAC design | 🔴 High | Before Dashboard 3/4 |
| 7 | Dashboard 3 (Command Center) | 🟡 Medium | After RBAC |
| 8 | Dashboard 4 (Org Admin) | 🟠 Low | After Dashboard 3 |
| 9.1 | Real voice monitoring (behind placeholder) | 🟠 Low | Opportunistic |
| 9.4 | Route emergency alerts through `email_queue` | 🟠 Low | Only if direct Apps Script path proves insufficient |
| 10 | Hardware (ESP32) | 🟠 Low | After software stable |

---

*Last updated to reflect: User Dashboard + Responder Dashboard + Postgres schema + both Apps Scripts wired together end-to-end, five real bugs found and fixed during that pass (UTF-16 requirements file, dob validator type mismatch, inverted email-first contact schema, transposed add_contact arguments, stale error message), and a working simulator demo account.*